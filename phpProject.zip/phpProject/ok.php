<<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>process successfully</title>
	<link rel="stylesheet" href="">
</head>
<body>
	<div align="center">
		<hr><br><br>
		<h1><?php echo $_GET['flag'];?> successfully.</h1>
		<a href="management.php">back to management page</a>
	</div>
</body>
</html>