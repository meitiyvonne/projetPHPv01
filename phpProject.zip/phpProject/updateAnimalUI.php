<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>update UI</title>
	<link rel="stylesheet" href="">
</head>
<body>
	<?php

	require_once ('AnimalService.class.php');

	$id = $_GET['id'];
	$animalService = new AnimalService();
	$animal = $animalService->getAnimalById($id);

	?>
	<div align="center">
	
	<h1>Update Animal</h1>
	<hr><br><br>
	<form action="animalProcess.php" method="post">
		<table>
			<tr>
				<td>id</td>
				<td><input type="text" name="id" value="<?php echo $animal->getId();?>" readonly></td>
			</tr>
			<tr>
				<td>type</td>
				<td><input type="text" name="type" value="<?php echo $animal->getType();?>"></td>
			</tr>
			<tr>
				<td>nom</td>
				<td><input type="text" name="nom" value="<?php echo $animal->getNom();?>"></td>
			</tr>
			<tr>
				<td>age</td>
				<td><input type="text" name="age" value="<?php echo $animal->getAge();?>"></td>
			</tr>
			<tr>
				<td>poids</td>
				<td><input type="text" name="poids" value="<?php echo $animal->getPoids();?>"></td>
			</tr>
			<tr>
				<td>couleur</td>
				<td><input type="text" name="couleur" value="<?php echo $animal->getCouleur(); ?>"></td>
			</tr>
			<tr>
				<td>proprietaire</td>
				<td><input type="text" name="proprietaire" value="<?php echo $animal->getProprietaire();?>"></td>
			</tr>
			<tr>
				<td>photo</td>
				<td><input type="file" name="image"></td>
			</tr>

			<input type="hidden" name="flag" value="update">

			<tr>
				<td colspan="2" align="center" style="padding: 10px;">
					<input type="submit" value="Add Animal">
					<input type="reset" value="Reset">
					<button type="Cancel"><a href="management.php">Cancel</a></button>
				</td>
				
			</tr>
		</table>

	</form>
	</div>

</body>
</html>