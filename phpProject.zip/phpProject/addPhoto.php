<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Add a photo to BD</title>
	<link rel="stylesheet" href="">
</head>
<body>
	<div align="center">
	<img src="images/logo.jpg" width="200px" style="padding:0">
		
	<h1>Upload Photo </h1>
	<hr>
		<form action="upload.php" method="post" enctype="multipart/form-data">
			<input type="file" name="image">
			<input type="submit" name="submit" value="Upload">
		</form>
		<br><br>
		<div><a href="management.php">back to management page</a></div>
	</div>
</body>
</html>