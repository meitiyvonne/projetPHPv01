<!-- <?php
	echo "Management page";
	echo "<br><a href='login.php'>back to login page</a>";
?> -->

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>management page</title>
	<link rel="stylesheet" href="">
	<script type="text/javascript">

		function confirmDel(val){

			return window.confirm("confirm to delete animal id"+val+"?");
		}
	</script>
</head>
<body>
	<div align="center">
		<img src="images/logo.jpg" width="200px" style="padding:0">
	<h1>Animaux List </h1>
	<hr>
	<?php

	require_once ('AnimalService.class.php');

	$animalService = new AnimalService();

	$result = $animalService->getAnimalList();


	echo "<table border='1px' width='700px'>";
	echo "<th>id</th>
		  <th>type</th>
		  <th>nom</th>
		  <th>age</th>
		  <th>poids</th>
		  <th>couleur</th>
		  <th>proprietaire</th>
		  <th>Delete</th>
		  <th>Update</th>";
	while ($row = mysqli_fetch_assoc($result)) {
		
		?>
		<!-- <img src="data:image/jpg;charset=utf8,base64,<?php echo base64_encode($row['photo']); ?>" /> -->
		<?php
		echo "<tr align='center'>
			  <td>{$row['id']}</td>
			  <td>{$row['type']}</td>
			  <td>{$row['nom']}</td>
			  <td>{$row['age']}</td>
			  <td>{$row['poids']}</td>
			  <td>{$row['couleur']}</td>
			  <td>{$row['proprietaire']}</td>
			  <td><a onclick='return confirmDel({$row['id']})' href='animalProcess.php?flag=delete&nom={$row['nom']}&id={$row['id']}'>Delete</a></td>
			  <td><a href='updateAnimalUI.php?id={$row['id']}'>Update</a></td>
			  </tr>";
	}

	echo "</table>";
	?>
	<br>
	<hr><br>
	<a href="management.php?id=$row['id']">back to Ambioner management</a>
	</div>
</body>
</html>