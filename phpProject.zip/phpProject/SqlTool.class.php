<?php

	require_once ('BD.php');

	class SqlTool{


		private $db;
		private $dbConn;
		private $dbClose;


		public function __construct()
		{
			$this->db = new DataBaseConnectionManager();
			$this->dbConn = $this->db->getConnection();
			// $this->dbClose = $this->db->close_connect();
		}

		public function execute_dql($sql){

			$res = mysqli_query($this->dbConn, $sql);

			return $res;
		}

		public function execute_dqlArray($sql)
		{
			$arr = array();
			$res = mysqli_query($this->dbConn, $sql);
			while($row=mysqli_fetch_array($res)){
				$arr[]=$row;
			}

			mysqli_free_result($res);
			return $arr;
		}

		public function execute_dml($sql)
		{
			$b = mysqli_query($this->dbConn, $sql);

			if(!$b){
				return 0;
			}else{
				if(mysqli_affected_rows($this->dbConn)>0){
					return 1;
				}else{
					return 2;
				}
			}
		}

		public function disConnect(){

			$this->dbClose;
		}
	}

?>