<?php

	require_once ('AnimalService.class.php');

	$animalService = new AnimalService();

	if(!empty($_REQUEST['flag'])){

		$flag = $_REQUEST['flag'];

		if($flag == "delete"){

			$id = $_REQUEST['id'];
			if($animalService->delEmpById($id) == 1){

				header("Location: ok.php?flag=$flag");
				exit();
			}
			else{
				header("Location: error.php?flag=$flag");
				exit();
			}
		}
		else if($flag == "update"){

			$id = $_POST['id'];
			$type = $_POST['type'];
			$nom = $_POST['nom'];
			$age = $_POST['age'];
			$poids = $_POST['poids'];
			$couleur = $_POST['couleur'];
			$proprietaire = $_POST['proprietaire'];
			// $photo = $_GET[''];

			$res = $animalService->updateAnimal($id, $type, $nom, $age, $poids, $couleur, $proprietaire);

			if($res==1){
				header("Location: ok.php?flag=$flag");
				exit();
			}
			else{
				header("Location: error.php?flag=$flag");
				exit();
			}

		}
		else if($flag == add){

			$type = $_POST['type'];
			$nom = $_POST['nom'];
			$age = $_POST['age'];
			$poids = $_POST['poids'];
			$couleur = $_POST['couleur'];
			$proprietaire = $_POST['proprietaire'];
			// $photo = $_POST['photo'];

			$res = $animalService->addAnimal($type, $nom, $age, $poids, $couleur, $proprietaire);

			if($res==1){
				header("Location: ok.php?flag=$flag");
				exit();
			}
			else{
				header("Location: error.php?flag=$flag");
				exit();
			}
		}
	}





?>