<?php

	require_once ('SqlTool.class.php');
	require_once ('Animal.class.php');

	class AnimalService{

		public function getAnimalList(){

			$sqlTool = new SqlTool();

			$sql = "select * from animal order by id";
			$res = $sqlTool->execute_dql($sql);
			return $res;
		}

		public function delEmpById($id){

			$sqlTool = new SqlTool();
			$sql = "delete from animal where id=$id";

			return $sqlTool->execute_dml($sql);
		}

		public function getAnimalById($id){

			$sql = "select * from animal where id=$id";
			$sqlTool = new SqlTool();
			$arr = $sqlTool->execute_dqlArray($sql);

			$animal = new Animal();
			$animal->setId($arr[0]['id']);
			$animal->setType($arr[0]['type']);
			$animal->setNom($arr[0]['nom']);
			$animal->setAge($arr[0]['age']);
			$animal->setPoids($arr[0]['poids']);
			$animal->setcouleur($arr[0]['couleur']);
			$animal->setproprietaire($arr[0]['proprietaire']);

			$sqlTool->disConnect();

			return $animal;

		}

		public function updateAnimal($id, $type, $nom, $age, $poids, $couleur, $proprietaire)
		{

			$sql = "update animal set type='$type', nom='$nom',
							age=$age,
							poids=$poids,
							couleur='$couleur',
							proprietaire='$proprietaire'
							where id = $id
					";

			$sqlTool = new SqlTool();
			$arr = $sqlTool->execute_dml($sql);
			var_dump($arr);
			$sqlTool->disConnect();
			return $arr;
		}

		public function addAnimal($type, $nom, $age, $poids, $couleur, $proprietaire)
		{
			$sql = "insert into animal (type, nom, age, poids, couleur, proprietaire)
				values('$type', '$nom', $age, $poids, '$couleur', '$proprietaire')";

			$sqlTool = new SqlTool();
			$res = $sqlTool->execute_dml($sql);

			$sqlTool->disConnect();
			return $res;
		}
	}

?>