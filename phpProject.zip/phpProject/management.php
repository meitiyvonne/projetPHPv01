<!-- <?php
	echo "Management page";
	echo "<br><a href='login.php'>back to login page</a>";
?> -->

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Ambioner management</title>
	<link rel="stylesheet" href="">
	<style type="text/css">
		body{
			margin: 0;
			padding: 0;
		}
		a{

			text-decoration: none;
		}
	</style>
</head>
<body>
	<div align="center">
	<img src="images/logo.jpg" width="200px" style="padding:0">
		
	<h1>Animaux Management </h1>
	<hr>
	<a href="animalList.php">Animal List</a><br><br>
	<a href="addAnimal.php">Add an animal</a><br><br>
	<a href="addPhoto.php">Upload photo</a><br><br>
	<a href="view.php">View photo</a><br><br>
	<a href="login.php">exit system</a><br><br>
	</div>
	<br>
	<hr><br>
</body>
</html>