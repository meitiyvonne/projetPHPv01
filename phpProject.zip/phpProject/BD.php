<?php
	// echo "Beinvenue a DB!";
	// echo "<br><a href='login.php'>back to login page</a>"

	/**
	 * DB connection
	 */
	class DataBaseConnectionManager extends mysqli
	{
		private $servername = 'localhost';
		private $username = 'root';
		private $password = '';
		private $dbName = 'animaux';
		private $conn;

		public function getConnection()
		{
			try {
				
				$conn = new mysqli($this->servername, $this->username, $this->password, $this->dbName);

				$conn->set_charset("utf8");

					if($conn->connect_error)
					{
						header("Location: login.php?errno=2");
					}
					else
					{
						$conn;
					} 
				}catch (Exception $e) 
				{
					header("Location: err.php"."--".$e.getMessage());
				}

			return $conn;
		}
		
	}
?>