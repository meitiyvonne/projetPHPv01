<?php

	require_once ('BD.php');

	$conn = new DataBaseConnectionManager();
	$dbConn = $conn->getConnection();


	$result = $dbConn->query("select images from animalImg where animalId=4");

	if(mysqli_num_rows($result)>0){

		$row = mysqli_fetch_assoc($result);
	}else{
		header("Location: error.php?flag='data-no-exist.'");
	}
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link rel="stylesheet" href="">
	<style type="text/css">
		.image{
			width: 300px;
			object-fit: cover;
		}
		img{
			width: 100%;
		}
	</style>
</head>
<body>
	
	<div class="image" ;>
		<img src="data:image/jpg;charset=utf8;base64,<?php echo base64_encode($row['images']);?>">
	</div>
	<div><a href="management.php">back to management page</a></div>
</body>
</html>