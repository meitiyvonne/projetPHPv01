<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link rel="stylesheet" href="">
	<title>Login & do BD</title>
	<style type="text/css">
		body{
			margin: 0;
			padding: 0;
		}
	</style>
</head>
<body>
	<div align="center">
		<img src="images/logo.jpg" width="200px" style="padding:0">
		<h1 style="margin: 0;">User Login</h1>
		<hr>
		<form action="loginVerify.php" method="post">
			<label>Nom</label>
			<div><input type="text" name="name"></div>
			<label>Password</label>
			<div><input type="Password" name="password"></div>
			<br>
			<div><input type="submit" value="Submit"></div>
		</form>
		<?php

			if(!empty($_GET['errmsg'])){
				$errmsg = $_GET['errmsg'];
				if($errmsg == 1){
					echo "<font color='red'>nom ou nip n'est pas bon!</font>";
				}
			}
			
		?>
	</div>
	<br>
	<hr><br>
</body>
</html>