<?php

	require_once ('BD.php');

	$conn = new DataBaseConnectionManager();
	$dbConn = $conn->getConnection();
	$id = $_POST['id'];

	if(isset($_POST['submit'])){

		if(!empty($_FILES['image']['name'])){

			$fileName = basename($_FILES['image']['name']);
			// print_r($fileName);
			$fileType = pathinfo($fileName, PATHINFO_EXTENSION);

			$allows = array('jpg','jpeg','png','gif');

			if(in_array($fileType, $allows)){

				$image = $_FILES['image']['tmp_name'];
				$imgContent = addslashes(file_get_contents($image));
				
				$sql = "insert into animalImg (animalId, images) values(4, '$imgContent');";

				$result = mysqli_query($dbConn, $sql);
				

				if($result){
					header("Location: ok.php?flag='image uploaded.'");
					exit();
				}else{
					header("Location: error.php?flag='image uploading failed.'");
					exit();
				}
			}else{
				header("Location: error.php?flag='image format incorrect.'");
				exit();
			}

		}
		else{
			header("Location: error.php?flag='Please select an image.'");
			exit();
		}
	}
?>