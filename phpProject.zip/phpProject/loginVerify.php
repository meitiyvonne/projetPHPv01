<?php

	require_once('BD.php');
	// get user informations
	$username = $_POST['name'];
	$password = $_POST['password'];


	// get BD Connection
	$con = new DataBaseConnectionManager();
	$dbConn = $con->getConnection();

	$sql = "select password, name from administration";

	$result = mysqli_query($dbConn, $sql);

	if($row = mysqli_fetch_assoc($result))
	{

		if($row['password'] == $password)
		{
			header("Location: management.php");
			exit();
		}

	}

	header("Location: login.php?errno=1");
	exit();

?>